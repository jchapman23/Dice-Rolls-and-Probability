#Josh Chapman
#9/26/2021
#CS307 Machine Learning
#
#This program is meant to read in three data sets of dice rolls stored as lists in a text file,
#and compute the probability of their distributions using two methods
#
#Method one is Max Likelihood Estimation, which uses no prior probability,
#instead computing the values directly from the instances/total data
#
#Method two finds a maximum for the numerator of Bayes Theorem, since the
#denomenator is proportional and therefore arbitrary


from random import randrange

data = open("dice_rolls.txt", "r")
one = data.readlines(1)[0].split(',')
two = data.readlines(2)[0].split(',')
three = data.readlines(3)[0].split(',')

def randNums(iterations): #function used to create data, copied to text file from terminal
    temp = []
    for i in range(0, iterations):
        x = randrange(0,10)
        if x == 0:
            temp.append(1)
        elif x == 1:
            temp.append(2)
        elif x == 2:
            temp.append(3)
        elif x == 3:
            temp.append(4)
        elif x == 4:
            temp.append(5)
        else:
            temp.append(6)
    print(temp)

def scenario1(list1, list2, list3):
    temp1 = [0, 0, 0, 0, 0, 0]
    for i in range(0, len(list1)):
        temp1[int(list1[i])-1]+=1
    
    temp2 = [0, 0, 0, 0, 0, 0]
    for i in range(0, len(list2)):
        temp2[int(list2[i])-1]+=1

    temp3 = [0, 0, 0, 0, 0, 0]
    for i in range(0, len(list3)):
        temp3[int(list3[i])-1]+=1

    for i in range(0,6):
        print(round(temp1[i]/len(list1), 2), '-', round(temp2[i]/len(list2), 2), '-', round(temp3[i]/len(list3), 2))
    
def partialBayes(list, theta, priorProb):
    liklihood = 1
    end = len(list)
    end = int(len(list)/2) #for inputs of 2000, since running all 2000 returns 0.0
    for i in range(0, end):
        if int(list[i]) == 6:
            liklihood= liklihood * theta
        else:
            liklihood= liklihood * (1-theta)
    return liklihood*priorProb


def main():
    list1 = three

    #scenario1(one, two, three)

    #scenario 2
    #first = partialBayes(list1, (1/2), 1)
    #second = partialBayes(list1, (6/10), 1)
    #third = partialBayes(list1, (1/6), 1)
    #print(first, second, third)

    #if first > second:
    #    if first > third:
    #        print('first')
    #    else:
    #        print('third')
    #else:
    #    if second > third:
    #        print('second')
    #    else:
    #        print('third')

    #scenario 3
    #first = partialBayes(list1, (1/2), .45)
    #second = partialBayes(list1, (6/10), .35)
    #third = partialBayes(list1, (1/6), .2)
    #print(first, second, third)

    #if first > second:
    #    if first > third:
    #        print('first')
    #    else:
    #        print('third')
    #else:
    #    if second > third:
    #        print('second')
    #    else:
    #        print('third')

    #scenario 4
    first = partialBayes(list1, (1/2), .52)
    second = partialBayes(list1, (6/10), .28)
    third = partialBayes(list1, (1/6), .2)
    print(first, second, third)

    if first > second:
        if first > third:
            print('first')
        else:
            print('third')
    else:
        if second > third:
            print('second')
        else:
            print('third')
main()
