Scenario 1
For this scenario a method was created to print out in three coloumns the probability
for each possible roll based on the Maximum Likelihood Estimation. This provided
a probability that a 6 would be rolled that matched the training data exactly,
since it is k/n instances of 6 over the total instances. This cannot estimate
the actual distribution however, unless as in data set 1 there is a perfect
50% distribution of 6's in the set.

For all tests of the list of 2000 instances, the list length had to be cut in half to
produce a number large enough for Python to not return 0.0

Scenario 2
For scenario 2, the theta in Bayes was set to 1 for all theta, to simulate the 
fact that all possible thetas share equal prior probability. With the partial Bayes
method returning the numerator of the Bayes function, we are able to determine
which value is the maximum between the possible thetas. For this scenario, any
theta is possible, but the values of .5, .6, and 1/6 were kept for uniformity.
The values were so small that they were expressed in terms of e^ some negative
number. With the 20 instance list, the values were relatively close, but as the
200 and 2000 instance lists were examined, the thetas of .6 and 1/6 began to
grow smaller much faster, with 1/6 producing a value so small in the 2000
instance list that python could only express it as 0.

Scenario 3
For scenario 3, prior probabilities were added. This meant that the final likelihood
values were multiplied by some constant at the end of their calculation, denoting
the skew provided by prior knowledge. This scenario again saw the theta of .5
being most likely, with the separation between .5 and .6 growing a bit more quickly as the
number of instances grew, but not by many degrees of exponential value. Again
the 2000 instance list was unable to produce a number large enough for Python
to read it as anything but 0.0 for the theta being 1/6. The biggest difference
seen was in the constants for the values given.

Scenario 4
This scenario slightly altered the prior probability from scenario 3, so that
the method is more sure that theta is .5, and decreasing our suspicion that
theta is .6. Here, there was again little difference in the overall rate of
separation between the values in terms of exponents, but there was a marked
difference in the constant values. This should be occuring since the prior probability
is not used constantly throughout calculation of the probability of data given theta,
and so theta affects the magnitude of the value more.